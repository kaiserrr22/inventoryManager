package main;

import java.util.Scanner;

public class addInventory extends InventoryManager {
	public void AddItem() {
		System.out.println("Hello World");
		return;
		}
	public void RemoveItem() {
		System.out.println("Hello Meow");
		return;
	}
	public void ViewInventory() {
		System.out.println("Hello Mello");
		return;
	}
}
