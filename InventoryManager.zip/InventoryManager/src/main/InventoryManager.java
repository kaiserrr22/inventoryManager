package main;
import java.util.Scanner;

public class InventoryManager {
	public static void main(String[] args) {
		
		addInventory Inventory = new addInventory();
		
		// declaring scanners in order to get the user's input.
		Scanner scanner = new Scanner(System.in);
			
		// initializes the user choice.
		int userChoice = 0;
		
		// this while statement will continue to run unless the user enters number 4.
		while (userChoice != 4) {
			
			// main menu, user will enter a number from 1-4.
			System.out.println("Inventory Manager [WIP]");
			System.out.println("Enter a number from 1-4, indicated by the functions below.");
			System.out.println("[1]. Add Item in Inventory");
			System.out.println("[2]. Remove Item in Inventory");
			System.out.println("[3]. View Items in Inventory");
			System.out.println("[4]. Exit Program");
			
			// user's choice, using int
			userChoice = scanner.nextInt();
			
			switch (userChoice) {
				case 1:
					Inventory.AddItem();
					break;
				case 2:
					Inventory.RemoveItem();
					break;
				case 3:
					Inventory.ViewInventory();
					break;
				case 4:
					System.out.println("Application Terminated.");
					System.exit(0);
					break;
				default:
					for (int i = 0; i < 1000; i++) {
						System.out.println("\n");
					}
					System.out.println("Invalid Choice");
					continue;
			}
				
		}
		
	}
}
